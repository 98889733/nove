/* NOVA engine: all wallpaper scenes, usable on any canvas (previews + the real wallpaper). */
(function (global) {
const DEFAULTS = { scene: 'stars', mode: 1, radius: 160, hue: 200, sat: 70, speed: 1, amount: 1, dim: 0,
  rainbow: false, ring: false, fps: 60, autostart: false, pauseBattery: true, applied: false };

const LIST = [
  ['stars', 'Stars & lines', 'Classic NOVA stars'],
  ['galaxy', 'Galaxy', 'Spiral of stars'],
  ['warp', 'Hyperspace', 'Fly through stars'],
  ['planets', 'Planets', 'Collisions and explosions'],
  ['fireworks', 'Fireworks', 'Rockets and sparks'],
  ['aurora', 'Aurora', 'Northern lights'],
  ['waves', 'Waves', 'Flowing lines'],
  ['fireflies', 'Fireflies', 'Glowing lights'],
  ['bubbles', 'Bubbles', 'Rising bubbles'],
  ['rain', 'Rain', 'Heavy rainfall'],
  ['snow', 'Snowfall', 'Soft snow'],
  ['matrix', 'Code rain', 'Falling symbols'],
  ['meteors', 'Meteor shower', 'Shooting stars'],
  ['plasma', 'Plasma', 'Flowing colors'],
  ['sunburst', 'Sunburst', 'Turning rays'],
  ['clock', 'Neon clock', 'Real time']
];
const SCENES = LIST.map(x => ({ id: x[0], name: x[1], desc: x[2] }));

function createEngine(cv) {
  const ctx = cv.getContext('2d');
  let W = 0, H = 0, T = 0, scene = null;
  const S = Object.assign({}, DEFAULTS);
  const M = { x: -1e4, y: -1e4, inside: false };
  const dir = () => S.mode == 2 ? -1 : 1;
  const reactive = () => S.mode != 0 && M.inside;
  const hue = () => S.rainbow ? (S.hue + T * 25) % 360 : S.hue;
  const C = (a = 1, dh = 0, l = 60) => `hsla(${(hue() + dh + 360) % 360},${S.sat}%,${l}%,${Math.max(0, Math.min(1, a))})`;
  const circ = (x, y, r) => { ctx.beginPath(); ctx.arc(x, y, Math.max(0.1, r), 0, 6.2832); ctx.fill(); };
  const rnd = (a, b) => a + Math.random() * (b - a);
  function force(x, y, str) {
    if (!reactive()) return [0, 0];
    const dx = M.x - x, dy = M.y - y, d = Math.hypot(dx, dy);
    if (d < 1 || d > S.radius) return [0, 0];
    const k = (1 - d / S.radius) * str * dir();
    return [dx / d * k, dy / d * k];
  }
  function shade(h, f) { const n = parseInt(h.slice(1), 16); const r = Math.min(255, ((n >> 16) & 255) * f) | 0, g = Math.min(255, ((n >> 8) & 255) * f) | 0, b = Math.min(255, (n & 255) * f) | 0; return `rgb(${r},${g},${b})`; }
  function planet(x, y, r, c, ring) {
    if (ring) { ctx.save(); ctx.translate(x, y); ctx.rotate(-.35); ctx.strokeStyle = 'rgba(230,215,180,.6)'; ctx.lineWidth = r * .16; ctx.beginPath(); ctx.ellipse(0, 0, r * 1.9, r * .5, 0, 0, 6.2832); ctx.stroke(); ctx.restore(); }
    const g = ctx.createRadialGradient(x - r * .4, y - r * .4, 0, x - r * .4, y - r * .4, r * 1.6);
    g.addColorStop(0, shade(c, 1.4)); g.addColorStop(.5, c); g.addColorStop(1, shade(c, .22));
    ctx.fillStyle = g; circ(x, y, r);
    if (ring) { ctx.save(); ctx.translate(x, y); ctx.rotate(-.35); ctx.strokeStyle = 'rgba(230,215,180,.75)'; ctx.lineWidth = r * .16; ctx.beginPath(); ctx.ellipse(0, 0, r * 1.9, r * .5, 0, 0, Math.PI); ctx.stroke(); ctx.restore(); }
  }
/* ---------- scenes ---------- */
function Stars(){
  const n=Math.round(90*S.amount),P=[];
  for(let i=0;i<n;i++){const a=rnd(0,6.283),sp=rnd(10,34);P.push({x:rnd(0,W),y:rnd(0,H),bx:Math.cos(a)*sp,by:Math.sin(a)*sp,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,s:rnd(1.2,2.8)})}
  return{
    update(dt){for(const p of P){const[fx,fy]=force(p.x,p.y,2600),k=reactive()?2.8:1.2;
      p.vx+=((p.bx-p.vx)*k+fx)*dt;p.vy+=((p.by-p.vy)*k+fy)*dt;p.x+=p.vx*dt*S.speed;p.y+=p.vy*dt*S.speed;
      if(p.x<-10)p.x=W+10;if(p.x>W+10)p.x=-10;if(p.y<-10)p.y=H+10;if(p.y>H+10)p.y=-10}},
    draw(){ctx.lineWidth=1;
      for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const dx=P[i].x-P[j].x,dy=P[i].y-P[j].y,d2=dx*dx+dy*dy;
        if(d2<14400){ctx.strokeStyle=C((1-d2/14400)*.6);ctx.beginPath();ctx.moveTo(P[i].x,P[i].y);ctx.lineTo(P[j].x,P[j].y);ctx.stroke()}}
      if(reactive())for(const p of P){const d=Math.hypot(p.x-M.x,p.y-M.y);if(d<S.radius){ctx.strokeStyle=C((1-d/S.radius)*.8);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(M.x,M.y);ctx.stroke()}}
      ctx.fillStyle=C(.92);for(const p of P)circ(p.x,p.y,p.s)}
  };
}
function Galaxy(){
  const n=Math.round(260*S.amount),P=[];
  for(let i=0;i<n;i++){const r=Math.pow(Math.random(),1.6);P.push({r,a:r*7+Math.floor(Math.random()*3)*2.0944+rnd(-.28,.28),s:rnd(.8,2.4),ox:0,oy:0,x:0,y:0})}
  return{
    update(dt){const cx=W/2,cy=H/2,R=Math.min(W,H)*.62,sm=Math.min(1,7*dt);
      for(const p of P){const th=p.a+T*.3*S.speed,bx=cx+Math.cos(th)*p.r*R,by=cy+Math.sin(th)*p.r*R*.62;let gx=0,gy=0;
        if(reactive()){const dx=M.x-bx,dy=M.y-by,d=Math.hypot(dx,dy);if(d>1&&d<S.radius){const k=(1-d/S.radius)*.85*dir();gx=dx*k;gy=dy*k}}
        p.ox+=(gx-p.ox)*sm;p.oy+=(gy-p.oy)*sm;p.x=bx+p.ox;p.y=by+p.oy}},
    draw(){const g=ctx.createRadialGradient(W/2,H/2,0,W/2,H/2,110);g.addColorStop(0,C(.45));g.addColorStop(1,C(0));ctx.fillStyle=g;ctx.fillRect(W/2-110,H/2-110,220,220);
      for(const p of P){ctx.fillStyle=C(.45+(1-p.r)*.55);circ(p.x,p.y,p.s)}}
  };
}
function Warp(){
  const n=Math.round(220*S.amount),P=[];
  const sp=p=>{p.x=rnd(-1,1);p.y=rnd(-1,1);p.z=1};
  for(let i=0;i<n;i++){const p={};sp(p);p.z=rnd(.05,1);P.push(p)}
  let vx=W/2,vy=H/2;
  return{
    update(dt){let tx=W/2,ty=H/2;if(reactive()){tx=dir()>0?M.x:W-M.x;ty=dir()>0?M.y:H-M.y}
      const sm=Math.min(1,4*dt);vx+=(tx-vx)*sm;vy+=(ty-vy)*sm;for(const p of P){p.z-=dt*.35*S.speed;if(p.z<.03)sp(p)}},
    draw(){const k=Math.max(W,H)*.2;ctx.lineCap='round';
      for(const p of P){const z1=p.z,z0=z1+.06*S.speed,x1=vx+p.x/z1*k,y1=vy+p.y/z1*k,x0=vx+p.x/z0*k,y0=vy+p.y/z0*k,near=1-z1;
        ctx.lineWidth=.6+near*2.2;ctx.strokeStyle=C(Math.min(1,near*1.2));ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.stroke()}}
  };
}
function Fall(kind){
  const rain=kind==='rain',n=Math.round((rain?170:120)*S.amount),P=[];
  const mk=(p,init)=>{p.x=rnd(0,W);p.y=init?rnd(0,H):-20;
    if(rain){p.bx=rnd(-30,30);p.by=rnd(700,1100);p.s=rnd(.4,1)}else{p.bx=rnd(-10,10);p.by=rnd(40,95);p.s=rnd(1.2,3.6);p.ph=rnd(0,6.28)}
    p.vx=p.bx;p.vy=p.by;return p};
  for(let i=0;i<n;i++)P.push(mk({},true));
  return{
    update(dt){for(const p of P){const[fx,fy]=force(p.x,p.y,rain?5000:1800);
      p.vx+=((p.bx-p.vx)*1.5+fx)*dt;p.vy+=((p.by-p.vy)*1.5+fy)*dt;p.x+=p.vx*dt*S.speed;p.y+=p.vy*dt*S.speed;
      if(p.y>H+20||p.x<-40||p.x>W+40)mk(p,false)}},
    draw(){if(rain){ctx.lineWidth=1.2;for(const p of P){ctx.strokeStyle=C(.25+p.s*.45);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-p.vx*.035,p.y-p.vy*.035);ctx.stroke()}}
      else for(const p of P){ctx.fillStyle=C(.45+p.s*.15);circ(p.x+Math.sin(T+p.ph)*10,p.y,p.s)}}
  };
}
function Fireflies(){
  const n=Math.round(45*S.amount),P=[];
  for(let i=0;i<n;i++)P.push({x:rnd(0,W),y:rnd(0,H),bx:rnd(-25,25),by:rnd(-25,25),vx:0,vy:0,ph:rnd(0,6.28),w:rnd(1,3),s:rnd(.7,1.3)});
  return{
    update(dt){for(const p of P){p.bx=Math.max(-35,Math.min(35,p.bx+rnd(-1,1)*360*dt));p.by=Math.max(-35,Math.min(35,p.by+rnd(-1,1)*360*dt));
      const[fx,fy]=force(p.x,p.y,2200);p.vx+=((p.bx-p.vx)*1.5+fx)*dt;p.vy+=((p.by-p.vy)*1.5+fy)*dt;
      p.x+=p.vx*dt*S.speed;p.y+=p.vy*dt*S.speed;p.ph+=p.w*dt*S.speed;
      if(p.x<-20)p.x=W+20;if(p.x>W+20)p.x=-20;if(p.y<-20)p.y=H+20;if(p.y>H+20)p.y=-20}},
    draw(){for(const p of P){const pu=.5+.5*Math.sin(p.ph),k=(.6+.4*pu)*p.s;
      ctx.fillStyle=C(.1+.12*pu);circ(p.x,p.y,18*k);ctx.fillStyle=C(.25+.25*pu);circ(p.x,p.y,9*k);ctx.fillStyle=C(.6+.4*pu);circ(p.x,p.y,3.5*k)}}
  };
}
function Matrix(){
  const cell=16,cols=Math.floor(W/cell),cs=[],ch='01ABCDEFGHJKLMNPRSTXYZ<>+=*#@';
  const mk=(c,init)=>{c.head=init?rnd(-H*.5,H):-rnd(0,H*.3);c.sp=rnd(120,320);c.len=8+Math.floor(Math.random()*14);c.ox=0};
  for(let i=0;i<cols;i++){const c={};mk(c,true);cs.push(c)}
  return{
    update(dt){const sm=Math.min(1,7*dt);cs.forEach((c,i)=>{c.head+=c.sp*dt*S.speed;if(c.head-c.len*cell>H)mk(c,false);
      let gx=0;if(reactive()){const x=i*cell+cell/2,dx=M.x-x,ad=Math.abs(dx);if(ad>1&&ad<S.radius)gx=dx*(1-ad/S.radius)*.6*dir()}
      c.ox+=(gx-c.ox)*sm})},
    draw(){ctx.font=cell+'px monospace';ctx.textAlign='center';const tick=Math.floor(T*6);
      cs.forEach((c,i)=>{const x=i*cell+cell/2+c.ox,hr=Math.floor(c.head/cell);
        for(let j=0;j<c.len;j++){const row=hr-j,y=(row+1)*cell;if(y<0||y>H+cell)continue;
          ctx.fillStyle=j===0?'#ebfff5':C(.8*(1-j/c.len));const h=row*73+i*131+(j<2?tick*7:0);
          ctx.fillText(ch[((h%ch.length)+ch.length)%ch.length],x,y)}})}
  };
}
function Waves(){
  let bump=0,lx=0,ly=0;
  return{
    update(dt){const on=reactive();if(on){lx=M.x;ly=M.y}bump+=((on?1:0)-bump)*Math.min(1,5*dt)},
    draw(){const sig=S.radius*.6;
      for(let k=0;k<6;k++){const base=H*(.3+.1*k),amp=26+6*k,sg=k%2?-1:1;ctx.beginPath();
        for(let x=0;x<=W+12;x+=10){const ph=x/W*6.283*(1.2+.25*k)+T*(.6+.2*k)*S.speed*sg;let y=base+Math.sin(ph)*amp;
          const dx=x-lx;y+=(ly-y)*Math.exp(-dx*dx/(2*sig*sig))*.55*bump*dir();x===0?ctx.moveTo(x,y):ctx.lineTo(x,y)}
        ctx.strokeStyle=C(.25+k*.12);ctx.lineWidth=2.5;ctx.stroke();ctx.lineTo(W+12,H);ctx.lineTo(0,H);ctx.closePath();ctx.fillStyle=C(.055);ctx.fill()}}
  };
}
function Aurora(){
  let bump=0,lx=0,ly=0;
  const top=(x,k)=>{const sg=k%2?-1:1,base=H*(.16+.13*k),ph=x/W*6.283*(.8+.3*k)+T*(.25+.1*k)*S.speed*sg;let y=base+Math.sin(ph)*60;
    const sig=S.radius*.8,dx=x-lx;y+=(ly-y)*Math.exp(-dx*dx/(2*sig*sig))*.5*bump*dir();return y};
  const th=(x,k)=>H*.26*(.75+.25*Math.sin(x/W*9+T*.5*S.speed+k));
  return{
    update(dt){const on=reactive();if(on){lx=M.x;ly=M.y}bump+=((on?1:0)-bump)*Math.min(1,4*dt)},
    draw(){for(let k=0;k<4;k++){ctx.beginPath();
      for(let x=0;x<=W+14;x+=14){const y=top(x,k);x===0?ctx.moveTo(x,y):ctx.lineTo(x,y)}
      for(let x=W+14;x>=0;x-=14)ctx.lineTo(x,top(x,k)+th(x,k));
      ctx.closePath();const y0=H*(.16+.13*k)-70,y1=y0+140+H*.26,g=ctx.createLinearGradient(0,y0,0,y1);
      g.addColorStop(0,C(0,k*35));g.addColorStop(.35,C(.47,k*35));g.addColorStop(1,C(0,k*35+25));ctx.fillStyle=g;ctx.fill()}}
  };
}
function Bubbles(){
  const n=Math.round(30*S.amount),P=[];
  const mk=(p,init)=>{p.x=rnd(0,W);p.y=init?rnd(0,H):H+40;p.bx=rnd(-8,8);p.by=-rnd(25,70);p.vx=p.bx;p.vy=p.by;p.s=rnd(8,36);p.ph=rnd(0,6.28);return p};
  for(let i=0;i<n;i++)P.push(mk({},true));
  return{
    update(dt){for(const p of P){const[fx,fy]=force(p.x,p.y,2400);p.vx+=((p.bx-p.vx)*1.5+fx)*dt;p.vy+=((p.by-p.vy)*1.5+fy)*dt;
      p.x+=p.vx*dt*S.speed;p.y+=p.vy*dt*S.speed;p.ph+=dt;if(p.y<-60)mk(p,false);if(p.x<-60)p.x=W+60;if(p.x>W+60)p.x=-60}},
    draw(){ctx.lineWidth=1.5;for(const p of P){const x=p.x+Math.sin(p.ph)*6;
      ctx.fillStyle=C(.1);circ(x,p.y,p.s);ctx.strokeStyle=C(.6);ctx.beginPath();ctx.arc(x,p.y,p.s,0,6.2832);ctx.stroke();
      ctx.fillStyle='rgba(255,255,255,.45)';circ(x-p.s*.35,p.y-p.s*.35,p.s*.16)}}
  };
}
function Fireworks(){
  const R=[],Sp=[];let timer=.3;
  const launch=(x,t)=>R.push({x,y:H+10,vy:-rnd(750,1000),t,h:rnd(0,360)});
  const burst=(x,y,h)=>{const n=Math.round(70*S.amount);for(let i=0;i<n;i++){const a=rnd(0,6.283),sp=rnd(.25,1)*280;
    Sp.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,l:rnd(.9,1.7),m:0,h:h+rnd(-25,25)})}};
  return{
    click(x,y){launch(x,y)},
    update(dt){timer-=dt;if(timer<=0){launch(W*rnd(.15,.85),H*rnd(.15,.5));timer=rnd(.7,1.8)/S.speed}
      for(let i=R.length-1;i>=0;i--){const r=R[i];r.y+=r.vy*dt;if(r.y<=r.t){burst(r.x,r.y,r.h);R.splice(i,1)}}
      for(let i=Sp.length-1;i>=0;i--){const s=Sp[i];if(!s.m)s.m=s.l;s.vy+=160*dt;s.vx*=1-.5*dt;s.vy*=1-.3*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;s.l-=dt;if(s.l<=0)Sp.splice(i,1)}},
    draw(){ctx.lineWidth=2;for(const r of R){ctx.strokeStyle='rgba(255,240,200,.9)';ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(r.x,r.y-r.vy*.05);ctx.stroke()}
      for(const s of Sp){const f=Math.max(0,s.l/s.m);ctx.fillStyle=`hsla(${(s.h+360)%360},65%,65%,${f})`;circ(s.x,s.y,1.2+f*1.8)}}
  };
}
function Planets(){
  const cols=['#E8A04A','#4A90E2','#D9534F','#9B6BD6','#4FC3B0','#C9B88A'];
  const n=Math.max(4,Math.round(6*S.amount)),P=[],D=[],Sh=[];let flash=0,fx0=0,fy0=0;
  const stars=Array.from({length:70},()=>({x:Math.random(),y:Math.random(),p:Math.random()}));
  const mk=(p,init)=>{p.s=rnd(26,70);p.c=cols[Math.floor(Math.random()*6)];p.ring=Math.random()<.35;p.alive=true;p.t=0;
    if(init){p.x=rnd(0,W);p.y=rnd(0,H);const a=rnd(0,6.28),sp=rnd(10,35);p.vx=Math.cos(a)*sp;p.vy=Math.sin(a)*sp}
    else{const side=Math.floor(Math.random()*4);
      if(side===0){p.x=-100;p.y=rnd(0,H)}else if(side===1){p.x=W+100;p.y=rnd(0,H)}else if(side===2){p.x=rnd(0,W);p.y=-100}else{p.x=rnd(0,W);p.y=H+100}
      const dx=W*rnd(.2,.8)-p.x,dy=H*rnd(.2,.8)-p.y,d=Math.max(1,Math.hypot(dx,dy)),sp=rnd(20,45);p.vx=dx/d*sp;p.vy=dy/d*sp}
    return p};
  for(let i=0;i<n;i++)P.push(mk({},true));
  function explode(a,b){
    const cx=(a.x+b.x)/2,cy=(a.y+b.y)/2,big=(a.s+b.s)/2;flash=1;fx0=cx;fy0=cy;Sh.push({x:cx,y:cy,age:0,r:180+big*2});
    const cnt=30+big*.8;
    for(let k=0;k<cnt&&D.length<260;k++){const src=k%2?a:b,ang=rnd(0,6.28),sp=rnd(40,330);
      D.push({x:cx+Math.cos(ang)*src.s*.4,y:cy+Math.sin(ang)*src.s*.4,vx:Math.cos(ang)*sp+src.vx*.5,vy:Math.sin(ang)*sp+src.vy*.5,
        l:rnd(1,2.2),m:0,c:Math.random()<.25?'#ffa040':src.c,s:rnd(1.5,4.5)})}
    a.alive=false;b.alive=false;a.t=rnd(2.5,4.5);b.t=rnd(3,5.5);
  }
  return{
    update(dt){
      for(const p of P)if(!p.alive){p.t-=dt;if(p.t<=0)mk(p,false)}
      for(const p of P){if(!p.alive)continue;let ax=0,ay=0;
        for(const q of P){if(q===p||!q.alive)continue;const dx=q.x-p.x,dy=q.y-p.y,d=Math.max(1,Math.hypot(dx,dy));
          const acc=220*q.s*q.s/Math.max(d*d,3600);ax+=dx/d*acc;ay+=dy/d*acc}
        const[fx,fy]=force(p.x,p.y,900);p.vx+=(ax+fx)*dt;p.vy+=(ay+fy)*dt;
        const sp=Math.hypot(p.vx,p.vy);if(sp>110){p.vx*=110/sp;p.vy*=110/sp}
        p.x+=p.vx*dt*S.speed;p.y+=p.vy*dt*S.speed;
        if(p.x<-170)p.x=W+170;if(p.x>W+170)p.x=-170;if(p.y<-170)p.y=H+170;if(p.y>H+170)p.y=-170}
      for(let i=0;i<P.length;i++){const a=P[i];if(!a.alive)continue;
        for(let j=i+1;j<P.length;j++){const b=P[j];if(!b.alive)continue;const lim=(a.s+b.s)*.8;
          if((a.x-b.x)**2+(a.y-b.y)**2<lim*lim){explode(a,b);break}}}
      for(let i=D.length-1;i>=0;i--){const d=D[i];if(!d.m)d.m=d.l;d.x+=d.vx*dt;d.y+=d.vy*dt;d.vx*=1-.6*dt;d.vy*=1-.6*dt;d.l-=dt;if(d.l<=0)D.splice(i,1)}
      for(let i=Sh.length-1;i>=0;i--){Sh[i].age+=dt/.7;if(Sh[i].age>=1)Sh.splice(i,1)}
      if(flash>0)flash=Math.max(0,flash-dt*2.5);
    },
    draw(){
      for(const s of stars){const tw=.5+.5*Math.sin(T*(.8+s.p)+s.p*20);ctx.fillStyle=`rgba(255,255,255,${.2+.6*tw})`;circ(s.x*W,s.y*H,.6+s.p*1.2)}
      for(const p of P)if(p.alive)planet(p.x,p.y,p.s,p.c,p.ring);
      for(const s of Sh){const k=s.age,r=s.r*(1-(1-k)*(1-k));ctx.strokeStyle=`rgba(255,200,120,${(1-k)*.85})`;ctx.lineWidth=4*(1-k)+1;ctx.beginPath();ctx.arc(s.x,s.y,r,0,6.2832);ctx.stroke()}
      for(const d of D){const f=Math.max(0,Math.min(1,d.l/d.m));ctx.globalAlpha=f*.28;ctx.fillStyle=d.c;circ(d.x,d.y,d.s*2.4);ctx.globalAlpha=f;circ(d.x,d.y,d.s*(.5+f*.5));ctx.globalAlpha=1}
      if(flash>0){const g=ctx.createRadialGradient(fx0,fy0,0,fx0,fy0,160);g.addColorStop(0,`rgba(255,235,190,${flash*.9})`);g.addColorStop(1,'rgba(255,200,120,0)');ctx.fillStyle=g;circ(fx0,fy0,160)}
    }
  };
}


/* ---------- extra scenes ---------- */
function Meteors() {
  const P = [], st = Array.from({ length: 90 }, () => ({ x: Math.random(), y: Math.random(), p: Math.random() }));
  let timer = 0;
  const launch = (x, y) => { const a = rnd(2.2, 2.7), sp = rnd(700, 1100); P.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp }); };
  return {
    update(dt) {
      timer -= dt;
      if (timer <= 0) { launch(rnd(.3 * W, 1.2 * W), -30); timer = rnd(.3, 1.4) / (S.amount * S.speed); }
      for (let i = P.length - 1; i >= 0; i--) {
        const p = P[i], [fx, fy] = force(p.x, p.y, 3000);
        p.vx += fx * dt; p.vy += fy * dt; p.x += p.vx * dt * S.speed; p.y += p.vy * dt * S.speed;
        if (p.x < -200 || p.y > H + 200) P.splice(i, 1);
      }
    },
    draw() {
      for (const s of st) { const tw = .5 + .5 * Math.sin(T * (.8 + s.p) + s.p * 20); ctx.fillStyle = `rgba(255,255,255,${.2 + .6 * tw})`; circ(s.x * W, s.y * H, .6 + s.p * 1.2); }
      ctx.lineCap = 'round';
      for (const p of P) {
        for (let k = 0; k < 7; k++) {
          ctx.strokeStyle = C((240 - k * 32) / 255); ctx.lineWidth = Math.max(.8, 3.2 - k * .4);
          ctx.beginPath(); ctx.moveTo(p.x - p.vx * k * .018, p.y - p.vy * k * .018); ctx.lineTo(p.x - p.vx * (k + 1) * .018, p.y - p.vy * (k + 1) * .018); ctx.stroke();
        }
        ctx.fillStyle = '#fff'; circ(p.x, p.y, 2.6);
      }
    }
  };
}
function Plasma() {
  return {
    update() { },
    draw() {
      const cell = 24, t = T * S.speed;
      for (let y = 0; y < H; y += cell) for (let x = 0; x < W; x += cell) {
        const cx = x + cell / 2, cy = y + cell / 2;
        let v = Math.sin(cx / 70 + t) + Math.sin(cy / 55 - t * 1.3) + Math.sin((cx + cy) / 90 + t * .7) + Math.sin(Math.hypot(cx - W / 2, cy - H / 2) / 70 - t);
        if (reactive()) { const d = Math.hypot(cx - M.x, cy - M.y) / S.radius; v += dir() * 3 * Math.exp(-d * d); }
        const nv = Math.max(0, Math.min(1, (v + 4) / 8));
        ctx.fillStyle = `hsl(${(hue() + nv * 80) % 360},${S.sat}%,${20 + nv * 50}%)`;
        ctx.fillRect(x, y, cell + 1, cell + 1);
      }
    }
  };
}
function Sunburst() {
  let cx = W / 2, cy = H / 2;
  return {
    update(dt) {
      let tx = W / 2, ty = H / 2;
      if (reactive()) { tx += (M.x - tx) * .6 * dir(); ty += (M.y - ty) * .6 * dir(); }
      const sm = Math.min(1, 4 * dt); cx += (tx - cx) * sm; cy += (ty - cy) * sm;
    },
    draw() {
      const n = 24, big = Math.hypot(W, H);
      for (let k = 0; k < n; k += 2) {
        const a0 = T * .3 * S.speed + k * 6.2832 / n, a1 = a0 + 6.2832 / n;
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a0) * big, cy + Math.sin(a0) * big); ctx.lineTo(cx + Math.cos(a1) * big, cy + Math.sin(a1) * big); ctx.closePath();
        ctx.fillStyle = C(.3); ctx.fill();
      }
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 140); g.addColorStop(0, C(.8)); g.addColorStop(1, C(0));
      ctx.fillStyle = g; circ(cx, cy, 140);
    }
  };
}
function Clock() {
  return {
    update() { },
    draw() {
      const d = new Date(), sec = d.getSeconds() + d.getMilliseconds() / 1000, min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
      const cx = W / 2, cy = H * .45, r = Math.min(W, H) * .36;
      ctx.lineCap = 'round';
      for (let k = 0; k < 60; k++) {
        const a = k * .10472 - 1.5708, big = k % 5 == 0, r0 = r * (big ? .88 : .94);
        ctx.strokeStyle = C(big ? .9 : .35); ctx.lineWidth = big ? 3.5 : 1.5;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); ctx.stroke();
      }
      const hand = (f, len, w, col) => { const a = f * 6.2832 - 1.5708; ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * r * len, cy + Math.sin(a) * r * len); ctx.stroke(); };
      hand(hr / 12, .5, 7, '#fff'); hand(min / 60, .75, 5, C(1)); hand(sec / 60, .85, 2, C(1, 150));
      ctx.fillStyle = '#fff'; circ(cx, cy, 7);
      ctx.fillStyle = C(.9); ctx.textAlign = 'center'; ctx.font = `bold ${Math.round(Math.min(W, H) * .12)}px system-ui`;
      ctx.fillText(String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), cx, H * .88);
    }
  };
}

  const MAP = {
    stars: Stars, galaxy: Galaxy, warp: Warp, planets: Planets, fireworks: Fireworks, aurora: Aurora, waves: Waves,
    fireflies: Fireflies, bubbles: Bubbles, rain: () => Fall('rain'), snow: () => Fall('snow'), matrix: Matrix,
    meteors: Meteors, plasma: Plasma, sunburst: Sunburst, clock: Clock
  };
  function build() { scene = (MAP[S.scene] || MAP.stars)(); }
  return {
    S, M, scenes: SCENES,
    resize(w, h, dpr) { dpr = dpr || 1; cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); W = w; H = h; build(); },
    setScene(id) { S.scene = id; build(); },
    set(patch) { Object.assign(S, patch); if ('amount' in patch) build(); },
    step(dt) { T += dt; if (scene) scene.update(dt); },
    draw() {
      ctx.globalAlpha = 1; ctx.fillStyle = `hsl(${hue()},35%,5%)`; ctx.fillRect(0, 0, W, H);
      if (scene) scene.draw();
      if (S.dim > 0) { ctx.fillStyle = `rgba(0,0,0,${S.dim / 100})`; ctx.fillRect(0, 0, W, H); }
      if (S.ring && reactive()) { ctx.fillStyle = C(.07); circ(M.x, M.y, S.radius); ctx.strokeStyle = C(.6); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(M.x, M.y, S.radius, 0, 6.2832); ctx.stroke(); }
    },
    click(x, y) { if (scene && scene.click) scene.click(x, y); }
  };
}
global.Nova = { createEngine, SCENES, DEFAULTS };
})(window);
