const { app, BrowserWindow, Menu, Tray, nativeImage, ipcMain, screen, powerMonitor } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

const DEFAULTS = { scene: 'stars', mode: 1, radius: 160, hue: 200, sat: 70, speed: 1, amount: 1, dim: 0,
  rainbow: false, ring: false, fps: 60, autostart: false, pauseBattery: true, applied: false };
let settings = Object.assign({}, DEFAULTS);
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
function load() { try { settings = Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(settingsFile(), 'utf8'))); } catch (e) { } }
function save() { try { fs.mkdirSync(path.dirname(settingsFile()), { recursive: true }); fs.writeFileSync(settingsFile(), JSON.stringify(settings)); } catch (e) { } }

let ctl = null, wp = null, tray = null, attached = false, cursorTimer = null, batTimer = null, quitting = false, locked = false;

if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => { if (!ctl) createControl(); else { ctl.show(); ctl.focus(); } });

const status = () => ({ running: !!wp, attached, scene: settings.scene });
function sendStatus() { if (ctl && !ctl.isDestroyed()) ctl.webContents.send('status', status()); }

function createControl() {
  ctl = new BrowserWindow({
    width: 1120, height: 740, minWidth: 900, minHeight: 620, backgroundColor: '#060914',
    title: 'NOVA Wallpapers', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
  });
  ctl.loadFile(path.join(__dirname, 'index.html'));
  ctl.on('close', (e) => { if (!quitting && wp) { e.preventDefault(); ctl.hide(); } });
  ctl.on('closed', () => { ctl = null; });
}

const PS = [
  '$ErrorActionPreference = "Stop"',
  'Add-Type -TypeDefinition @"',
  'using System;',
  'using System.Runtime.InteropServices;',
  'public static class NovaWin {',
  '  public delegate bool EnumProc(IntPtr h, IntPtr l);',
  '  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c, string t);',
  '  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string t);',
  '  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);',
  '  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc p, IntPtr l);',
  '  [DllImport("user32.dll")] public static extern IntPtr SetParent(IntPtr c, IntPtr p);',
  '  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool r);',
  '  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);',
  '  public static IntPtr FindWorker() {',
  '    IntPtr progman = FindWindow("Progman", null);',
  '    IntPtr res;',
  '    SendMessageTimeout(progman, 0x052C, new IntPtr(0xD), new IntPtr(1), 0, 1000, out res);',
  '    IntPtr worker = IntPtr.Zero;',
  '    EnumWindows(delegate(IntPtr h, IntPtr l) {',
  '      IntPtr shell = FindWindowEx(h, IntPtr.Zero, "SHELLDLL_DefView", null);',
  '      if (shell != IntPtr.Zero) { worker = FindWindowEx(IntPtr.Zero, h, "WorkerW", null); }',
  '      return true;',
  '    }, IntPtr.Zero);',
  '    if (worker == IntPtr.Zero) worker = FindWindowEx(progman, IntPtr.Zero, "WorkerW", null);',
  '    if (worker == IntPtr.Zero) worker = progman;',
  '    return worker;',
  '  }',
  '}',
  '"@',
  '$hwnd = [IntPtr]__HWND__',
  '$worker = [NovaWin]::FindWorker()',
  '[NovaWin]::SetParent($hwnd, $worker) | Out-Null',
  '[NovaWin]::MoveWindow($hwnd, 0, 0, __W__, __H__, $true) | Out-Null',
  '[NovaWin]::ShowWindow($hwnd, 5) | Out-Null',
  'Write-Output "OK"'
].join('\r\n');

function fallback(win) {
  attached = false;
  try {
    win.setFocusable(true);
    win.setFullScreen(true);
    win.webContents.on('before-input-event', (ev, input) => {
      if (input.type === 'keyDown' && input.key === 'Escape') stopWallpaper();
    });
  } catch (e) { }
  sendStatus();
}

function attach(win, d) {
  if (process.platform !== 'win32') { fallback(win); return; }
  try {
    const buf = win.getNativeWindowHandle();
    const hwnd = buf.length >= 8 ? buf.readBigUInt64LE(0).toString() : String(buf.readUInt32LE(0));
    const sf = d.scaleFactor || 1;
    const script = PS.replace('__HWND__', hwnd)
      .replace('__W__', String(Math.round(d.bounds.width * sf)))
      .replace('__H__', String(Math.round(d.bounds.height * sf)));
    const f = path.join(os.tmpdir(), 'nova-attach.ps1');
    fs.writeFileSync(f, script, 'utf8');
    const ps = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', f], { windowsHide: true });
    let out = '';
    ps.stdout.on('data', (x) => { out += x; });
    ps.on('error', () => fallback(win));
    ps.on('close', () => { if (out.includes('OK')) { attached = true; sendStatus(); } else fallback(win); });
  } catch (e) { fallback(win); }
}

function startCursor() {
  stopTimers();
  cursorTimer = setInterval(() => {
    if (!wp) return;
    const p = screen.getCursorScreenPoint();
    const b = screen.getPrimaryDisplay().bounds;
    const inside = p.x >= b.x && p.x < b.x + b.width && p.y >= b.y && p.y < b.y + b.height;
    wp.webContents.send('wp:cursor', { x: p.x - b.x, y: p.y - b.y, inside });
  }, 33);
  batTimer = setInterval(() => {
    if (!wp) return;
    let onBat = false;
    try { onBat = powerMonitor.isOnBatteryPower(); } catch (e) { }
    wp.webContents.send('wp:pause', locked || (settings.pauseBattery && onBat));
  }, 5000);
}
function stopTimers() { if (cursorTimer) clearInterval(cursorTimer); if (batTimer) clearInterval(batTimer); cursorTimer = batTimer = null; }

function startWallpaper() {
  if (wp) { wp.webContents.send('wp:settings', settings); return; }
  const d = screen.getPrimaryDisplay();
  const b = d.bounds;
  wp = new BrowserWindow({
    x: b.x, y: b.y, width: b.width, height: b.height, frame: false, show: false, skipTaskbar: true,
    focusable: false, resizable: false, movable: false, minimizable: false, maximizable: false,
    fullscreenable: true, hasShadow: false, backgroundColor: '#05070f',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false }
  });
  wp.loadFile(path.join(__dirname, 'wallpaper.html'));
  wp.once('ready-to-show', () => { wp.showInactive(); attach(wp, d); });
  wp.on('closed', () => {
    wp = null; attached = false; stopTimers(); sendStatus();
    if (!quitting && (!ctl || !ctl.isVisible())) { if (ctl) { ctl.show(); } else createControl(); }
  });
  startCursor();
  sendStatus();
}
function stopWallpaper() { if (wp) { try { wp.destroy(); } catch (e) { } } }

function applyLogin() {
  if (!app.isPackaged) return;
  try { app.setLoginItemSettings({ openAtLogin: !!settings.autostart, args: ['--wallpaper-start'] }); } catch (e) { }
}

ipcMain.handle('settings:get', () => settings);
ipcMain.handle('settings:set', (_e, patch) => { settings = Object.assign({}, settings, patch); save(); applyLogin(); return settings; });
ipcMain.handle('wallpaper:apply', (_e, s) => {
  settings = Object.assign({}, settings, s, { applied: true });
  save(); applyLogin(); startWallpaper();
  if (wp) wp.webContents.send('wp:settings', settings);
  return status();
});
ipcMain.handle('wallpaper:stop', () => { settings.applied = false; save(); stopWallpaper(); return status(); });
ipcMain.handle('status:get', () => status());
ipcMain.on('wp:ready', (e) => e.sender.send('wp:settings', settings));

function makeTray() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 16, height: 16 });
    tray = new Tray(img);
    tray.setToolTip('NOVA Wallpapers');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Open NOVA', click: () => { if (!ctl) createControl(); else { ctl.show(); ctl.focus(); } } },
      { label: 'Stop wallpaper', click: () => { settings.applied = false; save(); stopWallpaper(); } },
      { type: 'separator' },
      { label: 'Quit', click: () => { quitting = true; app.quit(); } }
    ]));
    tray.on('click', () => { if (!ctl) createControl(); else { ctl.show(); ctl.focus(); } });
  } catch (e) { }
}

app.whenReady().then(() => {
  load();
  Menu.setApplicationMenu(null);
  makeTray();
  try {
    powerMonitor.on('lock-screen', () => { locked = true; });
    powerMonitor.on('unlock-screen', () => { locked = false; });
  } catch (e) { }
  if (process.argv.includes('--wallpaper-start') && settings.applied) startWallpaper();
  else createControl();
});
app.on('before-quit', () => { quitting = true; });
app.on('window-all-closed', () => { if (!wp) app.quit(); });
