const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('nova', {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (p) => ipcRenderer.invoke('settings:set', p),
  apply: (s) => ipcRenderer.invoke('wallpaper:apply', s),
  stop: () => ipcRenderer.invoke('wallpaper:stop'),
  getStatus: () => ipcRenderer.invoke('status:get'),
  onStatus: (cb) => ipcRenderer.on('status', (_e, v) => cb(v)),
  onSettings: (cb) => ipcRenderer.on('wp:settings', (_e, v) => cb(v)),
  onCursor: (cb) => ipcRenderer.on('wp:cursor', (_e, v) => cb(v)),
  onPause: (cb) => ipcRenderer.on('wp:pause', (_e, v) => cb(v)),
  ready: () => ipcRenderer.send('wp:ready')
});
