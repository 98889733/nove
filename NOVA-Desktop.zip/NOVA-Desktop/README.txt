NOVA Wallpapers (PC)

Сборка через GitHub:
1. Создай репозиторий, загрузи этот zip (или все файлы) в корень.
2. Файл .github/workflows/build-desktop.yml должен лежать в репозитории по этому пути.
3. Открой вкладку Actions, дождись зелёной галочки, внизу страницы запуска в Artifacts скачай:
   - NOVA-Desktop-windows-latest  (exe: установщик и portable)
   - NOVA-Desktop-macos-latest    (zip для Mac)
   - NOVA-Desktop-ubuntu-latest   (AppImage для Linux)

Клавиши в приложении: S - настройки, F или F11 - полный экран.
Чтобы поставить обоями рабочего стола: Lively Wallpaper (Windows) или Plash (Mac), файл index.html.
